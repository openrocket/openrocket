package net.sf.openrocket.document.events;

import javax.swing.event.ChangeEvent;

public class DocumentChangeEvent extends ChangeEvent {

	public DocumentChangeEvent(Object source) {
		super(source);
	}

}

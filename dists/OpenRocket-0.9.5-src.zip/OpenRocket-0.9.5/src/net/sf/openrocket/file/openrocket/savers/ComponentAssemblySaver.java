package net.sf.openrocket.file.openrocket.savers;

public class ComponentAssemblySaver extends RocketComponentSaver {

	// No-op
	
}

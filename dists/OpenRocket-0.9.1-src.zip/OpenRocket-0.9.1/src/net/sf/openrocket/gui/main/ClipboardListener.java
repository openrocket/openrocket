package net.sf.openrocket.gui.main;

public interface ClipboardListener {

	public void clipboardChanged();
	
}

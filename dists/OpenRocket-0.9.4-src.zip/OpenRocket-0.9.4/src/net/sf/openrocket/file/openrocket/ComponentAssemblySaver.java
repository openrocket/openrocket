package net.sf.openrocket.file.openrocket;

public class ComponentAssemblySaver extends RocketComponentSaver {

	// No-op
	
}
